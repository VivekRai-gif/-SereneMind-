import { View, Text, Image, StyleSheet, Pressable } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialCommunityIcons } from '@expo/vector-icons';

export type Mentor = {
  id: string;
  name: string;
  role: string;
  specialty: string;
  avatar: string;
  accent: string[];
  greeting: string;
  emoji: string;
};

interface MentorCardProps {
  mentor: Mentor;
  onSelect: (mentor: Mentor) => void;
  isSelected?: boolean;
}

export default function MentorCard({ mentor, onSelect, isSelected }: MentorCardProps) {
  return (
    <Pressable onPress={() => onSelect(mentor)}>
      <LinearGradient
        colors={mentor.accent}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[styles.card, isSelected && styles.selectedCard]}
      >
        <View style={styles.avatarContainer}>
          <Image
            source={{ uri: mentor.avatar }}
            style={styles.avatar}
          />
          <Text style={styles.emoji}>{mentor.emoji}</Text>
        </View>
        <View style={styles.content}>
          <Text style={styles.name}>{mentor.name}</Text>
          <Text style={styles.role}>{mentor.role}</Text>
          <View style={styles.specialtyContainer}>
            <MaterialCommunityIcons name="star-four-points" size={16} color="#fff" />
            <Text style={styles.specialty}>{mentor.specialty}</Text>
          </View>
        </View>
      </LinearGradient>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    width: 280,
    padding: 20,
    borderRadius: 20,
    marginHorizontal: 10,
    marginVertical: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.3,
    shadowRadius: 20,
    elevation: 5,
  },
  selectedCard: {
    transform: [{ scale: 1.05 }],
    shadowOpacity: 0.5,
  },
  avatarContainer: {
    position: 'relative',
    alignItems: 'center',
    marginBottom: 15,
  },
  avatar: {
    width: 120,
    height: 120,
    borderRadius: 60,
    borderWidth: 3,
    borderColor: 'rgba(255,255,255,0.5)',
  },
  emoji: {
    position: 'absolute',
    bottom: -5,
    right: 70,
    fontSize: 24,
  },
  content: {
    alignItems: 'center',
  },
  name: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 4,
  },
  role: {
    fontSize: 16,
    color: 'rgba(255,255,255,0.8)',
    marginBottom: 10,
  },
  specialtyContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  specialty: {
    fontSize: 14,
    color: '#fff',
    marginLeft: 6,
  },
});