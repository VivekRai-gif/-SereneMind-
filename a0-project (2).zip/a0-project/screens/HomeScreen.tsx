import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import MentorCard, { Mentor } from '../components/MentorCard';
import { mentors } from '../data/mentors';
import { useNavigation } from '@react-navigation/native';

export default function HomeScreen() {
  const [selectedMentor, setSelectedMentor] = useState<Mentor | null>(null);
  const navigation = useNavigation();

  const handleMentorSelect = (mentor: Mentor) => {
    setSelectedMentor(mentor);
  };

  const handleStartChat = () => {
    if (selectedMentor) {
      // Navigate to chat screen (we'll implement this later)
      console.log('Starting chat with:', selectedMentor.name);
    }
  };

  return (
    <LinearGradient
      colors={['#1A1A2E', '#16213E', '#0F3460']}
      style={styles.container}
    >
      <SafeAreaView style={styles.content}>
        <View style={styles.header}>
          <Text style={styles.title}>Your Mental Wellness,</Text>
          <Text style={styles.subtitle}>Your Way</Text>
        </View>

        <Text style={styles.sectionTitle}>Choose Your Mentor</Text>
        
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.mentorList}
          decelerationRate="fast"
          snapToInterval={300}
        >
          {mentors.map((mentor) => (
            <MentorCard
              key={mentor.id}
              mentor={mentor}
              onSelect={handleMentorSelect}
              isSelected={selectedMentor?.id === mentor.id}
            />
          ))}
        </ScrollView>

        {selectedMentor && (
          <View style={styles.greetingContainer}>
            <Text style={styles.greeting}>{selectedMentor.greeting}</Text>
          </View>
        )}

        <Pressable
          style={[
            styles.startButton,
            !selectedMentor && styles.startButtonDisabled
          ]}
          onPress={handleStartChat}
          disabled={!selectedMentor}
        >
          <LinearGradient
            colors={selectedMentor ? ['#FF0099', '#FF4D4D'] : ['#666', '#888']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={styles.buttonGradient}
          >
            <Text style={styles.buttonText}>Start Your Journey</Text>
          </LinearGradient>
        </Pressable>
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    paddingTop: 20,
  },
  header: {
    paddingHorizontal: 20,
    marginBottom: 30,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#fff',
    textShadowColor: 'rgba(255,255,255,0.1)',
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 4,
  },
  subtitle: {
    fontSize: 32,
    fontWeight: '300',
    color: '#FF0099',
    textShadowColor: 'rgba(255,0,153,0.3)',
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 4,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#fff',
    marginLeft: 20,
    marginBottom: 10,
  },
  mentorList: {
    paddingHorizontal: 10,
  },
  greetingContainer: {
    margin: 20,
    padding: 15,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 15,
  },
  greeting: {
    color: '#fff',
    fontSize: 16,
    textAlign: 'center',
  },
  startButton: {
    margin: 20,
    marginTop: 'auto',
    borderRadius: 25,
    overflow: 'hidden',
  },
  startButtonDisabled: {
    opacity: 0.5,
  },
  buttonGradient: {
    paddingVertical: 15,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});