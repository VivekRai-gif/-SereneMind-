import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  ScrollView,
  Pressable,
  StyleSheet,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import Animated, {
  FadeInDown,
  FadeInUp,
} from 'react-native-reanimated';
import { mentors } from '../data/mentors';
import MentorCard from '../components/MentorCard';

const { width } = Dimensions.get('window');

export default function SignupScreen() {
  const navigation = useNavigation();
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    dateOfBirth: '',
    gender: '',
    password: '',
  });
  const [showPassword, setShowPassword] = useState(false);
  const [selectedMentor, setSelectedMentor] = useState(null);

  const handleSignup = () => {
    // TODO: Implement signup logic
    console.log('Signup data:', { ...formData, selectedMentor });
  };

  const renderInput = (
    label: string,
    value: string,
    key: string,
    icon: string,
    delay: number = 0,
    isPassword: boolean = false,
  ) => (
    <Animated.View 
      entering={FadeInDown.delay(delay).springify()}
      style={styles.inputContainer}
    >
      <Text style={styles.label}>{label}</Text>
      <View style={styles.inputWrapper}>
        <MaterialCommunityIcons name={icon} size={20} color="#FF0099" style={styles.inputIcon} />
        <TextInput
          style={styles.input}
          value={value}
          onChangeText={(text) => setFormData({ ...formData, [key]: text })}
          placeholderTextColor="#666"
          secureTextEntry={isPassword && !showPassword}
          autoCapitalize="none"
        />
        {isPassword && (
          <Pressable onPress={() => setShowPassword(!showPassword)} style={styles.showPassword}>
            <MaterialCommunityIcons
              name={showPassword ? 'eye-off' : 'eye'}
              size={20}
              color="#FF0099"
            />
          </Pressable>
        )}
      </View>
    </Animated.View>
  );

  return (
    <LinearGradient
      colors={['#1A1A2E', '#16213E', '#0F3460']}
      style={styles.container}
    >
      <SafeAreaView style={styles.content}>
        <ScrollView showsVerticalScrollIndicator={false}>
          <Animated.View 
            entering={FadeInUp.springify()}
            style={styles.header}
          >
            <Text style={styles.title}>Welcome to Your</Text>
            <Text style={styles.subtitle}>Mental Wellness Journey</Text>
          </Animated.View>

          {renderInput('Full Name', formData.fullName, 'fullName', 'account', 100)}
          {renderInput('Email', formData.email, 'email', 'email', 200)}
          {renderInput('Phone (Optional)', formData.phone, 'phone', 'phone', 300)}
          {renderInput('Date of Birth', formData.dateOfBirth, 'dateOfBirth', 'calendar', 400)}
          {renderInput('Gender (Optional)', formData.gender, 'gender', 'gender-male-female', 500)}
          {renderInput('Password', formData.password, 'password', 'lock', 600, true)}

          <Animated.Text 
            entering={FadeInDown.delay(700).springify()}
            style={styles.mentorTitle}
          >
            Choose Your Mentor
          </Animated.Text>

          <Animated.ScrollView
            entering={FadeInDown.delay(800).springify()}
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.mentorList}
            decelerationRate="fast"
            snapToInterval={300}
          >
            {mentors.map((mentor) => (
              <MentorCard
                key={mentor.id}
                mentor={mentor}
                onSelect={setSelectedMentor}
                isSelected={selectedMentor?.id === mentor.id}
              />
            ))}
          </Animated.ScrollView>

          <Animated.View 
            entering={FadeInDown.delay(900).springify()}
            style={styles.buttonContainer}
          >
            <Pressable onPress={handleSignup}>
              <LinearGradient
                colors={['#FF0099', '#FF4D4D']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={styles.button}
              >
                <Text style={styles.buttonText}>Create Account</Text>
              </LinearGradient>
            </Pressable>

            <View style={styles.socialButtons}>
              <Pressable style={styles.socialButton}>
                <MaterialCommunityIcons name="google" size={24} color="#fff" />
                <Text style={styles.socialButtonText}>Google</Text>
              </Pressable>
              <Pressable style={styles.socialButton}>
                <MaterialCommunityIcons name="apple" size={24} color="#fff" />
                <Text style={styles.socialButtonText}>Apple</Text>
              </Pressable>
            </View>

            <Pressable onPress={() => navigation.navigate('Login')}>
              <Text style={styles.loginLink}>
                Already have an account? <Text style={styles.loginLinkBold}>Log In</Text>
              </Text>
            </Pressable>
          </Animated.View>
        </ScrollView>
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    paddingTop: 20,
  },
  header: {
    paddingHorizontal: 20,
    marginBottom: 30,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#fff',
    textShadowColor: 'rgba(255,255,255,0.1)',
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 4,
  },
  subtitle: {
    fontSize: 32,
    fontWeight: '300',
    color: '#FF0099',
    textShadowColor: 'rgba(255,0,153,0.3)',
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 4,
  },
  inputContainer: {
    marginHorizontal: 20,
    marginBottom: 20,
  },
  label: {
    color: '#fff',
    fontSize: 16,
    marginBottom: 8,
    fontWeight: '500',
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
  },
  inputIcon: {
    padding: 12,
  },
  input: {
    flex: 1,
    color: '#fff',
    fontSize: 16,
    padding: 12,
  },
  showPassword: {
    padding: 12,
  },
  mentorTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#fff',
    marginLeft: 20,
    marginBottom: 10,
  },
  mentorList: {
    paddingHorizontal: 10,
  },
  buttonContainer: {
    padding: 20,
    gap: 20,
  },
  button: {
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  socialButtons: {
    flexDirection: 'row',
    gap: 10,
  },
  socialButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 12,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
    gap: 8,
  },
  socialButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '500',
  },
  loginLink: {
    color: '#fff',
    fontSize: 16,
    textAlign: 'center',
  },
  loginLinkBold: {
    fontWeight: 'bold',
    color: '#FF0099',
  },
});